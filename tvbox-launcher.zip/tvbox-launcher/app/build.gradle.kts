plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tvbox.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tvbox.launcher"
        minSdk = 21
        targetSdk = 30
        versionCode = 2
        versionName = "2.0"
    }

    // Chave fixa dentro do projeto: assim toda atualização usa a mesma assinatura
    // e dá para instalar por cima com "adb install -r" sem perder os ajustes.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        // O build que o GitHub gera já sai otimizado: código reduzido (R8), recursos
        // não usados removidos e sem modo depuração (menor e mais rápido em box fraca).
        getByName("debug") {
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
