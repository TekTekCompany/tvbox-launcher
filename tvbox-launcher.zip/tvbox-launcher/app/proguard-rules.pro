# Regras extras do R8. O launcher não usa reflexão, então nada especial é necessário.
-keep class com.tvbox.launcher.MainActivity { *; }
-keep class com.tvbox.launcher.SettingsActivity { *; }
