package com.tvbox.launcher

import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    /** Uma linha de ajuste. `change(+1/-1)` muda o valor; linhas de ação só respondem ao OK. */
    class Row(
        val title: String,
        val action: Boolean,
        val value: () -> String,
        val change: (Int) -> Unit
    )

    private lateinit var prefs: Prefs
    private lateinit var list: RecyclerView
    private lateinit var titleView: TextView
    private lateinit var hintView: TextView
    private lateinit var adapter: RowAdapter
    private val rows = ArrayList<Row>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContentView(R.layout.activity_settings)

        titleView = findViewById(R.id.settings_title)
        hintView = findViewById(R.id.settings_hint)
        list = findViewById(R.id.settings_list)

        buildRows()

        adapter = RowAdapter()
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.itemAnimator = null
        list.setHasFixedSize(true)

        applyTheme()
    }

    private fun applyTheme() {
        val t = Themes.preset(prefs.theme)
        Themes.applyWindow(this, prefs)
        titleView.setTextColor(t.text)
        hintView.setTextColor(t.textDim)
        val h = dp(prefs.marginDp())
        findViewById<View>(R.id.settings_root).setPadding(h, h / 2 + dp(6), h, dp(10))
    }

    // ---------- Linhas ----------

    private fun choice(title: String, options: List<String>, get: () -> Int, set: (Int) -> Unit): Row =
        Row(
            title, false,
            { options[get().coerceIn(0, options.size - 1)] },
            { dir -> set(cycle(get(), dir, options.size)) }
        )

    private fun toggle(title: String, on: String, off: String, get: () -> Boolean, set: (Boolean) -> Unit): Row =
        Row(title, false, { if (get()) on else off }, { _ -> set(!get()) })

    private fun action(title: String, label: String, run: () -> Unit): Row =
        Row(title, true, { label }, { _ -> run() })

    private fun buildRows() {
        rows.clear()

        rows.add(choice("Tema", Themes.presets.map { it.name }, { prefs.theme }, { prefs.theme = it }))
        rows.add(choice("Cor de destaque", Themes.accents.map { it.name }, { prefs.accent }, { prefs.accent = it }))
        rows.add(
            choice("Colunas", listOf("4", "5", "6", "7", "8"), { prefs.columns - 4 }, { prefs.columns = it + 4 })
        )
        rows.add(
            choice("Tamanho dos ícones", listOf("Pequeno", "Médio", "Grande"), { prefs.iconSize }, { prefs.iconSize = it })
        )
        rows.add(
            choice(
                "Estilo dos cartões", listOf("Quadrado", "Arredondado", "Bem redondo"),
                { prefs.cardStyle }, { prefs.cardStyle = it }
            )
        )
        rows.add(toggle("Nomes dos apps", "Mostrar", "Ocultar", { prefs.showLabels }, { prefs.showLabels = it }))
        rows.add(
            choice(
                "Margem da tela", listOf("Mínima", "Pequena", "Média", "Grande"),
                { prefs.margin }, { prefs.margin = it }
            )
        )
        rows.add(
            choice(
                "Papel de parede", listOf("Cor do tema", "Papel de parede do sistema"),
                { if (prefs.systemWallpaper) 1 else 0 }, { prefs.systemWallpaper = (it == 1) }
            )
        )
        rows.add(toggle("Relógio", "24 horas", "12 horas", { prefs.clock24 }, { prefs.clock24 = it }))
        rows.add(toggle("Mostrar data", "Sim", "Não", { prefs.showDate }, { prefs.showDate = it }))
        rows.add(
            choice("Ordem dos apps", listOf("A–Z", "Mais usados", "Recentes"), { prefs.sort }, { prefs.sort = it })
        )
        rows.add(
            choice(
                "Aba inicial",
                listOf("Favoritos", "Todos", "Streaming", "Jogos", "Mídia", "Sistema", "Outros"),
                { prefs.startTab }, { prefs.startTab = it }
            )
        )
        rows.add(
            toggle(
                "Esconder apps de fábrica", "Sim (WifiDisplay, DLNA, Bluetooth)", "Não",
                { prefs.hideFactory }, { prefs.hideFactory = it }
            )
        )
        rows.add(
            toggle(
                "Animações ao focar", "Ligadas", "Desligadas (mais leve)",
                { prefs.animations }, { prefs.animations = it }
            )
        )
        rows.add(action("Apps ocultos", "Gerenciar") { showHiddenDialog() })
        rows.add(action("Recarregar apps", "Atualizar") {
            AppRepository.invalidate()
            Toast.makeText(this, "A lista será atualizada ao voltar para o início", Toast.LENGTH_SHORT).show()
        })
        rows.add(action("Restaurar padrões", "Restaurar") { confirmReset() })
    }

    private fun changeRow(position: Int, dir: Int) {
        rows[position].change(dir)
        applyTheme()
        adapter.notifyItemRangeChanged(0, rows.size)
    }

    // ---------- Diálogos ----------

    private fun showHiddenDialog() {
        val apps = AppRepository.cached()
        if (apps == null) {
            AppRepository.load(this) { showHiddenDialog() }
            return
        }
        val sorted = apps.sortedBy { it.label.lowercase(Locale.ROOT) }
        val hidden = HashSet(prefs.hidden())
        val labels = Array(sorted.size) { sorted[it].label }
        val checked = BooleanArray(sorted.size) { sorted[it].packageName in hidden }

        AlertDialog.Builder(this)
            .setTitle("Apps ocultos (marcados ficam escondidos)")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                val pkg = sorted[which].packageName
                if (isChecked) hidden.add(pkg) else hidden.remove(pkg)
            }
            .setPositiveButton("Salvar") { _, _ -> prefs.setHidden(hidden) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Restaurar padrões?")
            .setMessage("Tema, cores, colunas e demais ajustes voltam ao original. Favoritos e apps ocultos são mantidos.")
            .setPositiveButton("Restaurar") { _, _ ->
                prefs.resetAppearance()
                applyTheme()
                adapter.notifyItemRangeChanged(0, rows.size)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Lista ----------

    private class RowHolder(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.row_title)
        val value: TextView = view.findViewById(R.id.row_value)
    }

    private inner class RowAdapter : RecyclerView.Adapter<RowHolder>() {

        override fun getItemCount(): Int = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_setting, parent, false)
            val h = RowHolder(v)

            v.setOnClickListener {
                val p = h.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) changeRow(p, 1)
            }
            v.setOnKeyListener { _, keyCode, event ->
                var handled = false
                if (event.action == KeyEvent.ACTION_DOWN) {
                    val p = h.bindingAdapterPosition
                    if (p != RecyclerView.NO_POSITION && !rows[p].action) {
                        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                            changeRow(p, 1)
                            handled = true
                        } else if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                            changeRow(p, -1)
                            handled = true
                        }
                    }
                }
                handled
            }
            return h
        }

        override fun onBindViewHolder(holder: RowHolder, position: Int) {
            val t = Themes.preset(prefs.theme)
            val accent = Themes.accent(prefs.accent)
            val row = rows[position]

            holder.itemView.background = cardBackground(t, accent, dpf(14), dp(3))
            holder.title.setTextColor(t.text)
            holder.title.text = row.title
            holder.value.setTextColor(accent)
            holder.value.text = if (row.action) row.value() else "‹  ${row.value()}  ›"
        }
    }
}
