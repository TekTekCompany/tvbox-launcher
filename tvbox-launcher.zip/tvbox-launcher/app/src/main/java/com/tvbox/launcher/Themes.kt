package com.tvbox.launcher

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.WindowManager
import androidx.core.graphics.ColorUtils

data class ThemePreset(
    val name: String,
    val bgTop: Int,
    val bgBottom: Int,
    val card: Int,
    val cardFocus: Int,
    val text: Int,
    val textDim: Int
)

data class Accent(val name: String, val color: Int)

object Themes {

    private fun c(hex: String): Int = Color.parseColor(hex)

    val presets: List<ThemePreset> = listOf(
        ThemePreset("Meia-noite", c("#0B1220"), c("#16213E"), c("#1B2542"), c("#2B3A66"), c("#F2F5FF"), c("#8F9BBD")),
        ThemePreset("Oceano", c("#06151C"), c("#0C2C3A"), c("#12303F"), c("#1C4A5F"), c("#EAF8FF"), c("#86AEBF")),
        ThemePreset("Pôr do sol", c("#1B0F2E"), c("#3A1450"), c("#2D1A47"), c("#46276B"), c("#FFF1F7"), c("#B79ACB")),
        ThemePreset("Floresta", c("#08150F"), c("#10281D"), c("#14301F"), c("#1F4A31"), c("#EDFFF4"), c("#8BB59B")),
        ThemePreset("Grafite", c("#121212"), c("#1E1E22"), c("#26262B"), c("#38383F"), c("#F4F4F6"), c("#9A9AA3")),
        ThemePreset("AMOLED", c("#000000"), c("#000000"), c("#111114"), c("#22222A"), c("#FFFFFF"), c("#8A8A94")),
        ThemePreset("Vinho", c("#1A0A0F"), c("#34101C"), c("#2B1219"), c("#47202D"), c("#FFF0F2"), c("#C09AA3")),
        ThemePreset("Claro", c("#EEF1F8"), c("#D9E1F2"), c("#FFFFFF"), c("#E3EBFF"), c("#14203A"), c("#5A6785"))
    )

    val accents: List<Accent> = listOf(
        Accent("Azul", c("#4F8CFF")),
        Accent("Ciano", c("#22D3EE")),
        Accent("Verde", c("#34D399")),
        Accent("Laranja", c("#FB923C")),
        Accent("Rosa", c("#F472B6")),
        Accent("Roxo", c("#A78BFA")),
        Accent("Vermelho", c("#F87171")),
        Accent("Amarelo", c("#FACC15"))
    )

    fun preset(i: Int): ThemePreset = presets[i.coerceIn(0, presets.size - 1)]

    fun accent(i: Int): Int = accents[i.coerceIn(0, accents.size - 1)].color

    /** Cor de texto legível sobre a cor de destaque. */
    fun onAccent(color: Int): Int =
        if (ColorUtils.calculateLuminance(color) > 0.55) c("#101828") else Color.WHITE

    /** Fundo da janela: degradê do tema ou papel de parede do sistema com uma película escura. */
    fun applyWindow(activity: Activity, prefs: Prefs) {
        val w = activity.window
        if (prefs.systemWallpaper) {
            w.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
            w.setBackgroundDrawable(ColorDrawable(c("#99000000")))
        } else {
            w.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
            val t = preset(prefs.theme)
            w.setBackgroundDrawable(
                GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(t.bgTop, t.bgBottom))
            )
        }
    }
}
