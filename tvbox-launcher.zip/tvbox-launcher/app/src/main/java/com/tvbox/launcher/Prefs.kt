package com.tvbox.launcher

import android.content.Context
import android.content.SharedPreferences

/** Todas as preferências do launcher em um só lugar. */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    // ---------- Aparência ----------

    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    var accent: Int
        get() = sp.getInt("accent", 0)
        set(v) { sp.edit().putInt("accent", v).apply() }

    /** 4 a 8 colunas. */
    var columns: Int
        get() = sp.getInt("columns", 6).coerceIn(4, 8)
        set(v) { sp.edit().putInt("columns", v.coerceIn(4, 8)).apply() }

    /** 0 pequeno, 1 médio, 2 grande. */
    var iconSize: Int
        get() = sp.getInt("iconSize", 1).coerceIn(0, 2)
        set(v) { sp.edit().putInt("iconSize", v).apply() }

    /** 0 quadrado, 1 arredondado, 2 bem redondo. */
    var cardStyle: Int
        get() = sp.getInt("cardStyle", 1).coerceIn(0, 2)
        set(v) { sp.edit().putInt("cardStyle", v).apply() }

    var showLabels: Boolean
        get() = sp.getBoolean("showLabels", true)
        set(v) { sp.edit().putBoolean("showLabels", v).apply() }

    var animations: Boolean
        get() = sp.getBoolean("animations", true)
        set(v) { sp.edit().putBoolean("animations", v).apply() }

    /** Margem da tela (overscan): 0 a 3. */
    var margin: Int
        get() = sp.getInt("margin", 1).coerceIn(0, 3)
        set(v) { sp.edit().putInt("margin", v).apply() }

    fun marginDp(): Int = intArrayOf(16, 32, 48, 64)[margin]

    var systemWallpaper: Boolean
        get() = sp.getBoolean("systemWallpaper", false)
        set(v) { sp.edit().putBoolean("systemWallpaper", v).apply() }

    var clock24: Boolean
        get() = sp.getBoolean("clock24", true)
        set(v) { sp.edit().putBoolean("clock24", v).apply() }

    var showDate: Boolean
        get() = sp.getBoolean("showDate", true)
        set(v) { sp.edit().putBoolean("showDate", v).apply() }

    // ---------- Organização ----------

    /** 0 A–Z, 1 mais usados, 2 recentes. */
    var sort: Int
        get() = sp.getInt("sort", 0).coerceIn(0, 2)
        set(v) { sp.edit().putInt("sort", v).apply() }

    /** Aba que abre primeiro (0 favoritos, 1 todos, ...). */
    var startTab: Int
        get() = sp.getInt("startTab", 1).coerceIn(0, 6)
        set(v) { sp.edit().putInt("startTab", v).apply() }

    var hideFactory: Boolean
        get() = sp.getBoolean("hideFactory", true)
        set(v) { sp.edit().putBoolean("hideFactory", v).apply() }

    // ---------- Favoritos e apps ocultos ----------

    fun favorites(): Set<String> = sp.getStringSet("favorites", emptySet()) ?: emptySet()

    fun toggleFavorite(pkg: String) {
        val s = HashSet(favorites())
        if (!s.add(pkg)) s.remove(pkg)
        sp.edit().putStringSet("favorites", s).apply()
    }

    fun hidden(): Set<String> = sp.getStringSet("hidden", emptySet()) ?: emptySet()

    fun setHidden(set: Set<String>) {
        sp.edit().putStringSet("hidden", HashSet(set)).apply()
    }

    fun hide(pkg: String) {
        val s = HashSet(hidden())
        s.add(pkg)
        setHidden(s)
    }

    // ---------- Categoria escolhida pelo usuário ----------

    fun categoryOverrides(): Map<String, Int> {
        val out = HashMap<String, Int>()
        for (e in sp.getStringSet("catOverride", emptySet()) ?: emptySet()) {
            val i = e.lastIndexOf('|')
            if (i > 0) {
                val ord = e.substring(i + 1).toIntOrNull()
                if (ord != null) out[e.substring(0, i)] = ord
            }
        }
        return out
    }

    fun setCategoryOverride(pkg: String, ordinal: Int?) {
        val set = HashSet<String>()
        for (e in sp.getStringSet("catOverride", emptySet()) ?: emptySet()) {
            if (!e.startsWith("$pkg|")) set.add(e)
        }
        if (ordinal != null) set.add("$pkg|$ordinal")
        sp.edit().putStringSet("catOverride", set).apply()
    }

    // ---------- Uso ----------

    fun recordLaunch(pkg: String) {
        sp.edit()
            .putInt("c:$pkg", launchCount(pkg) + 1)
            .putLong("t:$pkg", System.currentTimeMillis())
            .apply()
    }

    fun launchCount(pkg: String): Int = sp.getInt("c:$pkg", 0)

    fun lastLaunch(pkg: String): Long = sp.getLong("t:$pkg", 0L)

    /** Volta só a aparência/organização ao padrão; favoritos e apps ocultos continuam. */
    fun resetAppearance() {
        val e = sp.edit()
        for (k in listOf(
            "theme", "accent", "columns", "iconSize", "cardStyle", "showLabels", "animations",
            "margin", "systemWallpaper", "clock24", "showDate", "sort", "startTab", "hideFactory"
        )) e.remove(k)
        e.apply()
    }
}
