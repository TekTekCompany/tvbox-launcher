package com.tvbox.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Lista os apps em segundo plano (a tela nunca trava) e guarda o resultado em cache.
 * Os ícones já são convertidos para bitmaps pequenos, o que economiza memória em boxes de 1 GB.
 */
object AppRepository {

    private const val ICON_PX = 144

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var cache: List<AppEntry>? = null

    private val junkKeywords = listOf("wifidisplay", "wifi display", "wfd", "dlna", "bluetooth")

    fun cached(): List<AppEntry>? = cache

    fun invalidate() {
        cache = null
    }

    fun load(context: Context, callback: (List<AppEntry>) -> Unit) {
        val app = context.applicationContext
        executor.execute {
            val list = try {
                scan(app)
            } catch (e: Exception) {
                emptyList()
            }
            cache = list
            main.post { callback(list) }
        }
    }

    private fun scan(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val seen = HashSet<String>()
        val result = ArrayList<AppEntry>()

        for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || !seen.add(pkg)) continue

                val label = ri.loadLabel(pm).toString()
                val ai = ri.activityInfo.applicationInfo
                val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                val drawable: Drawable = try {
                    ri.loadIcon(pm)
                } catch (e: Exception) {
                    pm.defaultActivityIcon
                }

                result.add(
                    AppEntry(
                        label = label,
                        packageName = pkg,
                        component = ComponentName(pkg, ri.activityInfo.name),
                        icon = toBitmap(drawable),
                        category = categorize(pkg, label, ai, isSystem),
                        isSystem = isSystem,
                        junk = isJunk(pkg, label)
                    )
                )
            }
        }
        return result
    }

    private fun toBitmap(d: Drawable): Bitmap {
        val bmp = Bitmap.createBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        d.setBounds(0, 0, ICON_PX, ICON_PX)
        d.draw(canvas)
        return bmp
    }

    private fun isJunk(pkg: String, label: String): Boolean {
        val p = pkg.lowercase(Locale.ROOT)
        val l = label.lowercase(Locale.ROOT)
        return junkKeywords.any { p.contains(it) || l.contains(it) }
    }

    private fun categorize(pkg: String, label: String, ai: ApplicationInfo, isSystem: Boolean): Category {
        val p = pkg.lowercase(Locale.ROOT)
        val l = label.lowercase(Locale.ROOT)

        val streaming = listOf(
            "netflix", "youtube", "primevideo", "amazon.avod", "disney", "hbo", "globo", "pluto",
            "twitch", "spotify", "deezer", "crunchyroll", "paramount", "apple.atve", "telecine", "mubi"
        )
        if (streaming.any { p.contains(it) || l.contains(it) }) return Category.STREAMING

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            when (ai.category) {
                ApplicationInfo.CATEGORY_GAME -> return Category.GAMES
                ApplicationInfo.CATEGORY_VIDEO,
                ApplicationInfo.CATEGORY_AUDIO,
                ApplicationInfo.CATEGORY_IMAGE -> return Category.MEDIA
            }
        }
        if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return Category.GAMES

        val media = listOf("player", "kodi", "vlc", "gallery", "galeria", "music", "photo", "video", "media")
        if (media.any { p.contains(it) || l.contains(it) }) return Category.MEDIA

        val system = listOf(
            "settings", "configura", "filemanager", "files", "arquivos", "browser", "chrome", "market", "play.store"
        )
        if (system.any { p.contains(it) || l.contains(it) }) return Category.SYSTEM

        return if (isSystem) Category.SYSTEM else Category.OTHER
    }
}
