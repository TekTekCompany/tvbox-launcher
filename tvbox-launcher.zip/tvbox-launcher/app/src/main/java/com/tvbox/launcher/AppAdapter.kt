package com.tvbox.launcher

import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

/** Tudo que muda a aparência dos cartões. Se algo mudar, os cartões são reestilizados. */
data class Style(
    val theme: ThemePreset,
    val accent: Int,
    val iconDp: Int,
    val radiusDp: Int,
    val showLabels: Boolean,
    val animations: Boolean
)

/** Fundo de cartão com degradê suave, borda de destaque quando focado. */
fun cardBackground(t: ThemePreset, accent: Int, radius: Float, stroke: Int): StateListDrawable {
    val normal = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(ColorUtils.blendARGB(t.card, t.text, 0.06f), t.card)
    )
    normal.cornerRadius = radius

    val focused = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(ColorUtils.blendARGB(t.cardFocus, accent, 0.22f), t.cardFocus)
    )
    focused.cornerRadius = radius
    focused.setStroke(stroke, accent)

    val sl = StateListDrawable()
    sl.addState(intArrayOf(android.R.attr.state_focused), focused)
    sl.addState(intArrayOf(android.R.attr.state_pressed), focused)
    sl.addState(intArrayOf(), normal)
    return sl
}

private val APP_DIFF = object : DiffUtil.ItemCallback<AppEntry>() {
    override fun areItemsTheSame(oldItem: AppEntry, newItem: AppEntry): Boolean =
        oldItem.packageName == newItem.packageName

    override fun areContentsTheSame(oldItem: AppEntry, newItem: AppEntry): Boolean =
        oldItem.label == newItem.label && oldItem.icon === newItem.icon
}

class AppAdapter(
    private val onClick: (AppEntry) -> Unit,
    private val onLongClick: (AppEntry) -> Unit
) : ListAdapter<AppEntry, AppAdapter.Holder>(APP_DIFF) {

    lateinit var style: Style

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
        var applied: Style? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        val h = Holder(v)

        v.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(getItem(p))
        }
        v.setOnLongClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onLongClick(getItem(p))
            true
        }
        v.setOnFocusChangeListener { view, focused ->
            if (style.animations) {
                val s = if (focused) 1.07f else 1f
                view.animate().scaleX(s).scaleY(s).setDuration(110).start()
                view.elevation = if (focused) 18f else 0f
            }
        }
        return h
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val app = getItem(position)
        val s = style
        if (holder.applied != s) {
            applyStyle(holder, s)
            holder.applied = s
        }
        holder.icon.setImageBitmap(app.icon)
        holder.label.text = app.label
    }

    private fun applyStyle(h: Holder, s: Style) {
        val ctx = h.itemView.context
        h.itemView.background = cardBackground(s.theme, s.accent, ctx.dpf(s.radiusDp), ctx.dp(3))

        val size = ctx.dp(s.iconDp)
        val lp = h.icon.layoutParams
        lp.width = size
        lp.height = size
        h.icon.layoutParams = lp

        h.label.visibility = if (s.showLabels) View.VISIBLE else View.GONE
        h.label.setTextColor(s.theme.text)

        val padV = if (s.showLabels) ctx.dp(14) else ctx.dp(18)
        h.itemView.setPadding(ctx.dp(10), padV, ctx.dp(10), padV)

        h.itemView.scaleX = 1f
        h.itemView.scaleY = 1f
        h.itemView.elevation = 0f
    }
}
