package com.tvbox.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val tabTitles = listOf("Favoritos", "Todos", "Streaming", "Jogos", "Mídia", "Sistema", "Outros")

    private lateinit var prefs: Prefs
    private lateinit var root: LinearLayout
    private lateinit var grid: RecyclerView
    private lateinit var tabsBar: LinearLayout
    private lateinit var settingsBtn: TextView
    private lateinit var empty: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var greeting: TextView
    private lateinit var adapter: AppAdapter
    private lateinit var layoutManager: GridLayoutManager

    private var apps: List<AppEntry> = emptyList()
    private var loaded = false
    private var selectedTab = 1
    private var initialFocusPending = true
    private var tabFocusEnabled = false
    private var appliedStyle: Style? = null

    private val handler = Handler(Looper.getMainLooper())
    private val ptBr = Locale("pt", "BR")

    private val reloadRunnable = Runnable { AppRepository.invalidate(); reload() }

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 20_000)
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            handler.removeCallbacks(reloadRunnable)
            handler.postDelayed(reloadRunnable, 600)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        grid = findViewById(R.id.grid)
        tabsBar = findViewById(R.id.tabs)
        settingsBtn = findViewById(R.id.btn_settings)
        empty = findViewById(R.id.empty)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        greeting = findViewById(R.id.greeting)

        selectedTab = prefs.startTab.coerceIn(0, tabTitles.size - 1)

        layoutManager = GridLayoutManager(this, prefs.columns)
        adapter = AppAdapter(::launch, ::showOptions)
        grid.layoutManager = layoutManager
        grid.adapter = adapter
        grid.setHasFixedSize(true)
        grid.setItemViewCacheSize(24)
        grid.itemAnimator = null
        grid.addOnChildAttachStateChangeListener(object : RecyclerView.OnChildAttachStateChangeListener {
            override fun onChildViewAttachedToWindow(view: View) {
                updateUpFocus(view)
            }

            override fun onChildViewDetachedFromWindow(view: View) {}
        })

        settingsBtn.isFocusable = true
        settingsBtn.isClickable = true
        settingsBtn.setOnClickListener { openSettings() }

        buildTabs()
        refreshTabStates()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, filter)
    }

    override fun onResume() {
        super.onResume()
        applyAppearance()

        val cached = AppRepository.cached()
        if (cached != null) {
            apps = cached
            loaded = true
            render()
        } else {
            reload()
        }

        updateClock()
        handler.postDelayed(tick, 20_000)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    // Home de novo: volta para a aba inicial e para o primeiro app.
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        selectedTab = prefs.startTab.coerceIn(0, tabTitles.size - 1)
        refreshTabStates()
        initialFocusPending = true
        tabFocusEnabled = false
        render()
        grid.scrollToPosition(0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Launcher não fecha com Voltar.
        val start = prefs.startTab.coerceIn(0, tabTitles.size - 1)
        if (selectedTab != start) {
            selectedTab = start
            refreshTabStates()
            render()
        }
        grid.scrollToPosition(0)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            val f = currentFocus
            if (f != null) {
                val vh = grid.findContainingViewHolder(f)
                val pos = vh?.bindingAdapterPosition ?: -1
                if (pos >= 0 && pos < adapter.currentList.size) {
                    showOptions(adapter.currentList[pos])
                    return true
                }
            }
            openSettings()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    // ---------- Aparência ----------

    private fun currentStyle(): Style = Style(
        theme = Themes.preset(prefs.theme),
        accent = Themes.accent(prefs.accent),
        iconDp = intArrayOf(48, 64, 80)[prefs.iconSize],
        radiusDp = intArrayOf(6, 16, 28)[prefs.cardStyle],
        showLabels = prefs.showLabels,
        animations = prefs.animations
    )

    private fun applyAppearance() {
        val t = Themes.preset(prefs.theme)
        val accent = Themes.accent(prefs.accent)

        Themes.applyWindow(this, prefs)

        val h = dp(prefs.marginDp())
        root.setPadding(h, h / 2 + dp(6), h, dp(10))

        greeting.setTextColor(t.text)
        clock.setTextColor(t.text)
        date.setTextColor(t.textDim)
        empty.setTextColor(t.textDim)
        date.visibility = if (prefs.showDate) View.VISIBLE else View.GONE

        styleTab(settingsBtn, t, accent)
        for (i in 0 until tabsBar.childCount) {
            styleTab(tabsBar.getChildAt(i) as TextView, t, accent)
        }

        if (layoutManager.spanCount != prefs.columns) {
            layoutManager.spanCount = prefs.columns
        }

        val newStyle = currentStyle()
        val changed = appliedStyle != newStyle
        adapter.style = newStyle
        appliedStyle = newStyle
        if (changed) adapter.notifyDataSetChanged()
    }

    private fun styleTab(tv: TextView, t: ThemePreset, accent: Int) {
        val r = dpf(24)

        fun shape(fill: Int, stroke: Int): GradientDrawable {
            val g = GradientDrawable()
            g.setColor(fill)
            g.cornerRadius = r
            if (stroke != 0) g.setStroke(dp(2), stroke)
            return g
        }

        val bg = StateListDrawable()
        bg.addState(intArrayOf(android.R.attr.state_selected, android.R.attr.state_focused), shape(accent, t.text))
        bg.addState(intArrayOf(android.R.attr.state_selected), shape(accent, 0))
        bg.addState(intArrayOf(android.R.attr.state_focused), shape(t.cardFocus, accent))
        bg.addState(intArrayOf(), shape(t.card, 0))
        tv.background = bg

        tv.setTextColor(
            ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_selected), intArrayOf()),
                intArrayOf(Themes.onAccent(accent), t.text)
            )
        )
    }

    private fun updateClock() {
        val pattern = if (prefs.clock24) "HH:mm" else "h:mm a"
        val now = Date()
        clock.text = SimpleDateFormat(pattern, ptBr).format(now)
        date.text = SimpleDateFormat("EEEE, d 'de' MMMM", ptBr).format(now)
            .replaceFirstChar { it.uppercase() }

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        greeting.text = when {
            hour in 5..11 -> "Bom dia"
            hour in 12..17 -> "Boa tarde"
            else -> "Boa noite"
        }
    }

    // ---------- Abas ----------

    private fun buildTabs() {
        tabsBar.removeAllViews()
        tabTitles.forEachIndexed { index, title ->
            val tv = TextView(this)
            tv.id = View.generateViewId()
            tv.text = title
            tv.textSize = 16f
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(22), dp(10), dp(22), dp(10))
            tv.isFocusable = true
            tv.isClickable = true
            tv.setOnClickListener { selectTab(index) }
            tv.setOnFocusChangeListener { _, focused ->
                if (focused && tabFocusEnabled) selectTab(index)
            }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = dp(10)
            tabsBar.addView(tv, lp)
        }
    }

    private fun selectTab(index: Int) {
        if (index == selectedTab) return
        selectedTab = index
        refreshTabStates()
        render()
    }

    private fun refreshTabStates() {
        for (i in 0 until tabsBar.childCount) {
            tabsBar.getChildAt(i).isSelected = (i == selectedTab)
        }
    }

    // ---------- Dados ----------

    private fun reload() {
        AppRepository.load(this) { list ->
            if (!isFinishing && !isDestroyed) {
                apps = list
                loaded = true
                render()
            }
        }
    }

    private fun effectiveCategory(a: AppEntry, overrides: Map<String, Int>): Category {
        val ord = overrides[a.packageName]
        val all = Category.values()
        return if (ord != null && ord >= 0 && ord < all.size) all[ord] else a.category
    }

    private fun matches(tab: Int, a: AppEntry, cat: Category, fav: Set<String>): Boolean = when (tab) {
        0 -> a.packageName in fav
        1 -> true
        2 -> cat == Category.STREAMING
        3 -> cat == Category.GAMES
        4 -> cat == Category.MEDIA
        5 -> cat == Category.SYSTEM
        else -> cat == Category.OTHER
    }

    private fun render() {
        val fav = prefs.favorites()
        val hidden = prefs.hidden()
        val hideJunk = prefs.hideFactory
        val overrides = prefs.categoryOverrides()

        val list = ArrayList<AppEntry>()
        for (a in apps) {
            if (a.packageName in hidden) continue
            if (hideJunk && a.junk) continue
            if (matches(selectedTab, a, effectiveCategory(a, overrides), fav)) list.add(a)
        }

        when (prefs.sort) {
            1 -> list.sortWith(
                compareByDescending<AppEntry> { prefs.launchCount(it.packageName) }
                    .thenBy { it.label.lowercase(Locale.ROOT) }
            )
            2 -> list.sortWith(
                compareByDescending<AppEntry> { prefs.lastLaunch(it.packageName) }
                    .thenBy { it.label.lowercase(Locale.ROOT) }
            )
            else -> list.sortBy { it.label.lowercase(Locale.ROOT) }
        }

        if (list.isEmpty() && loaded) {
            empty.visibility = View.VISIBLE
            empty.text = if (selectedTab == 0) {
                "Nenhum favorito ainda. Segure OK (ou aperte Menu) em um app para favoritar."
            } else {
                "Nenhum app nesta categoria."
            }
        } else {
            empty.visibility = View.GONE
        }

        adapter.submitList(list) { onListCommitted() }
    }

    private fun onListCommitted() {
        for (i in 0 until grid.childCount) updateUpFocus(grid.getChildAt(i))

        if (initialFocusPending && loaded) {
            initialFocusPending = false
            grid.post {
                val first = grid.findViewHolderForAdapterPosition(0)?.itemView
                if (first != null) {
                    first.requestFocus()
                } else {
                    tabsBar.getChildAt(selectedTab)?.requestFocus()
                }
                tabFocusEnabled = true
            }
        }
    }

    /** Só a primeira fileira sobe para a aba atual; as outras sobem para a fileira de cima. */
    private fun updateUpFocus(child: View) {
        val pos = grid.getChildAdapterPosition(child)
        val tab = tabsBar.getChildAt(selectedTab)
        child.nextFocusUpId =
            if (pos >= 0 && pos < layoutManager.spanCount && tab != null) tab.id else View.NO_ID
    }

    // ---------- Ações ----------

    private fun launch(app: AppEntry) {
        prefs.recordLaunch(app.packageName)
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        intent.component = app.component
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        try {
            startActivity(intent)
        } catch (e: Exception) {
            val fallback = packageManager.getLaunchIntentForPackage(app.packageName)
            if (fallback != null) {
                try {
                    startActivity(fallback)
                } catch (e2: Exception) {
                    // sem o que fazer: o app não abre
                }
            }
        }
    }

    private fun showOptions(app: AppEntry) {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        val isFav = app.packageName in prefs.favorites()
        labels.add(if (isFav) "Remover dos favoritos" else "Adicionar aos favoritos")
        actions.add {
            prefs.toggleFavorite(app.packageName)
            render()
        }

        labels.add("Mover para outra categoria")
        actions.add { chooseCategory(app) }

        labels.add("Ocultar da tela")
        actions.add {
            prefs.hide(app.packageName)
            render()
        }

        labels.add("Informações do app")
        actions.add {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:${app.packageName}"))
            )
        }

        if (!app.isSystem) {
            labels.add("Desinstalar")
            actions.add {
                startActivity(Intent(Intent.ACTION_DELETE).setData(Uri.parse("package:${app.packageName}")))
            }
        }

        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun chooseCategory(app: AppEntry) {
        val names = ArrayList<String>()
        names.add("Automática")
        for (c in Category.values()) names.add(c.label)

        AlertDialog.Builder(this)
            .setTitle("Categoria de ${app.label}")
            .setItems(names.toTypedArray()) { _, which ->
                prefs.setCategoryOverride(app.packageName, if (which == 0) null else which - 1)
                render()
            }
            .show()
    }
}
