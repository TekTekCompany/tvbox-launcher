package com.tvbox.launcher

import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private data class Tab(val titleRes: Int, val filter: (AppEntry, Set<String>) -> Boolean)

    // Apps que a TV box traz de fábrica e que o usuário quer esconder da tela inicial.
    private val hiddenKeywords = listOf("wifidisplay", "wifi display", "wfd", "dlna", "bluetooth")

    private val tabs = listOf(
        Tab(R.string.tab_favorites) { a, fav -> a.packageName in fav },
        Tab(R.string.tab_all) { _, _ -> true },
        Tab(R.string.tab_streaming) { a, _ -> a.category == Category.STREAMING },
        Tab(R.string.tab_games) { a, _ -> a.category == Category.GAMES },
        Tab(R.string.tab_media) { a, _ -> a.category == Category.MEDIA },
        Tab(R.string.tab_system) { a, _ -> a.category == Category.SYSTEM }
    )

    private lateinit var grid: RecyclerView
    private lateinit var tabsBar: LinearLayout
    private lateinit var empty: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var adapter: AppAdapter

    private var apps: List<AppEntry> = emptyList()
    private var selectedTab = 1
    private val handler = Handler(Looper.getMainLooper())

    private val prefs by lazy { getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    private fun favorites(): Set<String> = prefs.getStringSet("favorites", emptySet()) ?: emptySet()

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("EEEE, d 'de' MMMM", Locale.getDefault()).format(now)
            handler.postDelayed(this, 15_000)
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = reload()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        grid = findViewById(R.id.grid)
        tabsBar = findViewById(R.id.tabs)
        empty = findViewById(R.id.empty)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)

        adapter = AppAdapter(::launch, ::showOptions)
        grid.layoutManager = GridLayoutManager(this, 6)
        grid.adapter = adapter

        buildTabs()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, filter)
    }

    override fun onResume() {
        super.onResume()
        reload()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    // Home já é a tela inicial: o botão Home só volta para "Todos" e ao primeiro item.
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        selectTab(1)
        grid.scrollToPosition(0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Launcher não deve fechar com Voltar.
        if (selectedTab != 1) selectTab(1) else grid.scrollToPosition(0)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            (currentFocus?.let { grid.findContainingViewHolder(it) })?.let {
                val pos = it.bindingAdapterPosition
                visibleApps().getOrNull(pos)?.let(::showOptions)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- Abas ----------

    private fun buildTabs() {
        tabsBar.removeAllViews()
        tabs.forEachIndexed { index, tab ->
            val tv = TextView(this).apply {
                setText(tab.titleRes)
                textSize = 16f
                setTextColor(resources.getColor(R.color.text_primary, theme))
                gravity = Gravity.CENTER
                setPadding(36, 14, 36, 14)
                background = resources.getDrawable(R.drawable.tab_bg, theme)
                isFocusable = true
                isClickable = true
                setOnClickListener { selectTab(index) }
                setOnFocusChangeListener { _, focused -> if (focused) selectTab(index, keepFocus = true) }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = 16 }
            tabsBar.addView(tv, lp)
        }
        refreshTabStates()
    }

    private fun selectTab(index: Int, keepFocus: Boolean = false) {
        if (selectedTab == index && keepFocus) return
        selectedTab = index
        refreshTabStates()
        render()
    }

    private fun refreshTabStates() {
        for (i in 0 until tabsBar.childCount) tabsBar.getChildAt(i).isSelected = (i == selectedTab)
    }

    // ---------- Dados ----------

    private fun reload() {
        apps = loadApps()
        render()
    }

    private fun visibleApps(): List<AppEntry> {
        val fav = favorites()
        return apps.filter { tabs[selectedTab].filter(it, fav) }
    }

    private fun render() {
        val list = visibleApps()
        adapter.submit(list)
        if (list.isEmpty()) {
            empty.visibility = View.VISIBLE
            empty.setText(if (selectedTab == 0) R.string.empty_favorites else R.string.empty_category)
        } else {
            empty.visibility = View.GONE
        }
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val seen = HashSet<String>()
        val result = ArrayList<AppEntry>()

        for (category in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val label = ri.loadLabel(pm).toString()
                if (isHidden(pkg, label)) continue
                val ai = ri.activityInfo.applicationInfo
                val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                result.add(
                    AppEntry(
                        label = label,
                        packageName = pkg,
                        component = android.content.ComponentName(pkg, ri.activityInfo.name),
                        icon = ri.loadIcon(pm),
                        category = categorize(pkg, label, ai, isSystem),
                        isSystem = isSystem
                    )
                )
            }
        }
        return result.sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun isHidden(pkg: String, label: String): Boolean {
        val p = pkg.lowercase(Locale.ROOT)
        val l = label.lowercase(Locale.ROOT)
        return hiddenKeywords.any { p.contains(it) || l.contains(it) }
    }

    private fun categorize(pkg: String, label: String, ai: ApplicationInfo, isSystem: Boolean): Category {
        val p = pkg.lowercase(Locale.ROOT)
        val l = label.lowercase(Locale.ROOT)

        val streaming = listOf(
            "netflix", "youtube", "primevideo", "amazon.avod", "disney", "hbo", "max", "globo", "pluto",
            "twitch", "spotify", "deezer", "crunchyroll", "star", "paramount", "apple.atve", "telecine", "mubi"
        )
        if (streaming.any { p.contains(it) || l.contains(it) }) return Category.STREAMING

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            when (ai.category) {
                ApplicationInfo.CATEGORY_GAME -> return Category.GAMES
                ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_AUDIO,
                ApplicationInfo.CATEGORY_IMAGE -> return Category.MEDIA
            }
        } else if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) {
            return Category.GAMES
        }

        val media = listOf("player", "kodi", "vlc", "gallery", "galeria", "music", "photo", "video", "media")
        if (media.any { p.contains(it) || l.contains(it) }) return Category.MEDIA

        val system = listOf("settings", "configura", "filemanager", "files", "arquivos", "browser", "chrome", "market", "play.store")
        if (system.any { p.contains(it) || l.contains(it) }) return Category.SYSTEM

        return if (isSystem) Category.SYSTEM else Category.OTHER
    }

    // ---------- Ações ----------

    private fun launch(app: AppEntry) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = app.component
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
        }
    }

    private fun showOptions(app: AppEntry) {
        val isFav = app.packageName in favorites()
        val options = mutableListOf(
            getString(if (isFav) R.string.opt_unfavorite else R.string.opt_favorite),
            getString(R.string.opt_info),
            getString(if (app.isSystem) R.string.opt_uninstall_unavailable else R.string.opt_uninstall)
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(options.toTypedArray()) { _, which ->
                when (which) {
                    0 -> toggleFavorite(app.packageName)
                    1 -> startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                            .setData(Uri.parse("package:${app.packageName}"))
                    )
                    2 -> if (!app.isSystem) {
                        startActivity(
                            Intent(Intent.ACTION_DELETE).setData(Uri.parse("package:${app.packageName}"))
                        )
                    }
                }
            }
            .show()
    }

    private fun toggleFavorite(pkg: String) {
        val set = favorites().toMutableSet()
        if (!set.add(pkg)) set.remove(pkg)
        prefs.edit().putStringSet("favorites", set).apply()
        render()
    }
}
