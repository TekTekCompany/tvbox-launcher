package com.tvbox.launcher

import android.content.ComponentName
import android.graphics.Bitmap

enum class Category(val label: String) {
    STREAMING("Streaming"),
    GAMES("Jogos"),
    MEDIA("Mídia"),
    SYSTEM("Sistema"),
    OTHER("Outros")
}

class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val icon: Bitmap,
    val category: Category,
    val isSystem: Boolean,
    /** App de fábrica (WifiDisplay, DLNA, Bluetooth...). */
    val junk: Boolean
)
