package com.tvbox.launcher

import android.content.ComponentName
import android.graphics.drawable.Drawable

enum class Category { STREAMING, GAMES, MEDIA, SYSTEM, OTHER }

data class AppEntry(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val icon: Drawable,
    val category: Category,
    val isSystem: Boolean
)
