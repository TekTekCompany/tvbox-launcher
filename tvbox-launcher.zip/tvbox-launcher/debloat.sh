#!/usr/bin/env bash
# Remove (para o usuário atual) os apps de fábrica: WifiDisplay, Bluetooth e DLNA.
# Não apaga da ROM: dá para restaurar com:  adb shell cmd package install-existing <pacote>
#
# Como usar:
#   1) Na TV box: Configurações > Sobre > toque 7x em "Número da versão"
#      Depois: Opções do desenvolvedor > ativar "Depuração USB" / "Depuração ADB (rede)"
#   2) No PC:     adb connect IP_DA_BOX:5555     (ou plugue um cabo USB)
#   3)            ./debloat.sh

set -u

PATTERNS=("wifidisplay" "wfd" "dlna" "bluetooth")
# Pacotes de núcleo: removê-los pode derrubar o Bluetooth de controles/teclados.
CORE_WARN=("com.android.bluetooth" "com.android.bluetoothmidiservice")

if ! command -v adb >/dev/null 2>&1; then
  echo "adb não encontrado. Instale o Android platform-tools." >&2
  exit 1
fi

if ! adb get-state >/dev/null 2>&1; then
  echo "Nenhum dispositivo conectado. Use: adb connect IP_DA_BOX:5555" >&2
  exit 1
fi

BACKUP="removidos_$(date +%Y%m%d_%H%M%S).txt"
: > "$BACKUP"

ALL=$(adb shell pm list packages | tr -d '\r' | sed 's/^package://')

CANDIDATES=()
while IFS= read -r pkg; do
  [ -z "$pkg" ] && continue
  lower=$(echo "$pkg" | tr 'A-Z' 'a-z')
  for pat in "${PATTERNS[@]}"; do
    if [[ "$lower" == *"$pat"* ]]; then
      CANDIDATES+=("$pkg")
      break
    fi
  done
done <<< "$ALL"

if [ ${#CANDIDATES[@]} -eq 0 ]; then
  echo "Nenhum pacote correspondente encontrado."
  exit 0
fi

echo "Pacotes encontrados:"
printf '  - %s\n' "${CANDIDATES[@]}"
echo

for pkg in "${CANDIDATES[@]}"; do
  warn=""
  for core in "${CORE_WARN[@]}"; do
    [ "$pkg" = "$core" ] && warn="  [ATENÇÃO: serviço de núcleo do Bluetooth; controles/teclados BT podem parar]"
  done
  read -r -p "Remover $pkg ?$warn [s/N] " ans
  case "$ans" in
    s|S|y|Y)
      out=$(adb shell pm uninstall -k --user 0 "$pkg" 2>&1 | tr -d '\r')
      if [[ "$out" == *Success* ]]; then
        echo "  removido."
        echo "$pkg" >> "$BACKUP"
      else
        echo "  falhou ($out). Tentando desativar..."
        out=$(adb shell pm disable-user --user 0 "$pkg" 2>&1 | tr -d '\r')
        echo "  $out"
        [[ "$out" == *disabled* ]] && echo "$pkg" >> "$BACKUP"
      fi
      ;;
    *) echo "  mantido." ;;
  esac
done

echo
echo "Lista salva em $BACKUP"
echo "Para restaurar um app:  adb shell cmd package install-existing NOME_DO_PACOTE"
echo
echo "Opcional: definir o novo launcher como padrão depois de instalá-lo:"
echo "  adb install -r app-debug.apk"
echo "  (aperte Home na box e escolha 'Início' > Sempre)"
