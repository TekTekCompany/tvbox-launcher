# Launcher para TV box — versão 2

Launcher Android TV feito para controle remoto: bonito, personalizável e leve.

## Visual
- Saudação (Bom dia / Boa tarde / Boa noite), relógio grande e data.
- Abas: **Favoritos, Todos, Streaming, Jogos, Mídia, Sistema, Outros** (← → troca de aba).
- Cartões com degradê, borda de destaque e zoom suave ao focar.
- 8 temas (Meia-noite, Oceano, Pôr do sol, Floresta, Grafite, AMOLED, Vinho, Claro)
  e 8 cores de destaque.

## Personalização (botão **Ajustes** ou tecla **Menu** fora de um app)
Use ← → para mudar o valor, ou OK para avançar.

| Ajuste | Opções |
|---|---|
| Tema / Cor de destaque | 8 temas · 8 cores |
| Colunas | 4 a 8 |
| Tamanho dos ícones | Pequeno · Médio · Grande |
| Estilo dos cartões | Quadrado · Arredondado · Bem redondo |
| Nomes dos apps | Mostrar · Ocultar |
| Margem da tela | Mínima a Grande (corrige TV que corta as bordas) |
| Papel de parede | Cor do tema · Papel de parede do sistema |
| Relógio / Data | 24h ou 12h · mostrar ou não |
| Ordem dos apps | A–Z · Mais usados · Recentes |
| Aba inicial | qualquer uma das 7 |
| Esconder apps de fábrica | WifiDisplay, DLNA e Bluetooth |
| Apps ocultos | você escolhe quais esconder |
| Animações ao focar | Ligadas · Desligadas (mais leve) |

**Segure OK** (ou aperte **Menu**) em um app: favoritar, mover de categoria, ocultar,
informações e desinstalar.

## Otimização
- A lista de apps é carregada em segundo plano; a tela nunca trava.
- Ícones convertidos para bitmaps pequenos, guardados em cache.
- Lista com DiffUtil e reaproveitamento de itens (menos trabalho na troca de abas).
- Fundo desenhado uma única vez (sem sobreposição de camadas).
- A tela não é recriada ao trocar resolução/HDMI.
- APK compilado com R8 (código e recursos reduzidos) e sem modo depuração.
- Em box de 1 GB: ligue **Animações: Desligadas** e use ícones pequenos.

## Atualizar pelo GitHub (fluxo pelo celular)
1. No repositório, **Add file > Upload files** e envie este `tvbox-launcher.zip`
   (mesmo nome: ele substitui o anterior). O build roda sozinho.
2. Em **Actions**, baixe o `launcher-apk` e instale com o Termux.

## Instalar na TV
Esta versão usa uma **assinatura fixa**. Na primeira vez que for instalar por cima da
versão 1, desinstale a antiga (a assinatura mudou):

```
adb connect IP_DA_TV:5555
adb uninstall com.tvbox.launcher
adb install app-debug.apk
adb shell cmd package set-home-activity com.tvbox.launcher/.MainActivity
```

Dali em diante, as atualizações são só `adb install -r app-debug.apk` (mantém os ajustes).

## Remover os apps de fábrica de verdade
`./debloat.sh` (com `adb` no PC) ou, no Termux:

```
adb shell pm list packages | grep -iE "wifidisplay|wfd|dlna|bluetooth"
adb shell pm uninstall -k --user 0 NOME_DO_PACOTE
```

Reversível com `adb shell cmd package install-existing NOME_DO_PACOTE`.
Mantenha `com.android.bluetooth` se usa controle ou teclado Bluetooth.
