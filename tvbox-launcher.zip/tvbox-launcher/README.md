# Launcher para TV box (Android TV / AOSP)

Launcher novo, organizado por categorias e feito para controle remoto.

## O que ele faz
- Abas: **Favoritos, Todos, Streaming, Jogos, Mídia, Sistema** (troque com ← → no controle).
- Grade de 6 colunas, foco com destaque azul e leve zoom.
- Relógio e data no topo.
- **Segure OK** (ou botão **Menu**) em um app: favoritar, informações, desinstalar.
- Esconde automaticamente apps com "wifidisplay", "wfd", "dlna" e "bluetooth" no nome/pacote.
  Para mudar, edite `hiddenKeywords` em `MainActivity.kt`.
- Todo o resto continua aparecendo.

## Compilar
1. Abra a pasta no Android Studio e clique em *Build > Build APK*, ou rode `gradle assembleDebug`
   (precisa do Android SDK).
2. O APK sai em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar
```
adb connect IP_DA_BOX:5555
adb install -r app-debug.apk
```
Aperte **Home** na box e escolha **Início > Sempre**.

## Remover os apps de fábrica de verdade
`./debloat.sh` localiza os pacotes WifiDisplay, Bluetooth e DLNA, pergunta um a um e remove
só para o usuário atual (reversível com `adb shell cmd package install-existing <pacote>`).
Não precisa de root.

## Observação
`com.android.bluetooth` é o serviço de núcleo: se você usa controle ou teclado Bluetooth,
mantenha-o. Esconder o app da tela (feito pelo launcher) já resolve a organização.
